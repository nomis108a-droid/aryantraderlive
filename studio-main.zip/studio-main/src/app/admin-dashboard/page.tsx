
"use client"

import { useState, useEffect, useMemo } from "react";
import { useRouter } from "next/navigation";
import { useFirestore, useUser, useDoc } from "@/firebase";
import { 
  collection, query, orderBy, limit, doc, updateDoc, deleteDoc,
  serverTimestamp, getDocs, startAfter, limitToLast, endBefore, QueryDocumentSnapshot, 
  where, onSnapshot
} from "firebase/firestore";
import { 
  Loader2, RefreshCw, Instagram, Save,
  Trash2, ExternalLink, Play, Wallet, Zap,
  X as CloseIcon, Fingerprint, Eye, 
  Search, ChevronLeft, ChevronRight, Check, ShieldAlert
} from "lucide-react";
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { Textarea } from "@/components/ui/textarea"
import { ProofGallery } from "@/components/proof-gallery";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"

const BATCH_SIZE = 50;

export default function AdminDashboard() {
  const db = useFirestore();
  const router = useRouter();
  const { toast } = useToast();
  const { user, loading: authLoading } = useUser();

  // AUTH STATE
  const [isAdmin, setIsAdmin] = useState(false);
  const [authChecked, setAuthChecked] = useState(false);

  // DATA STATE
  const [creators, setCreators] = useState<any[]>([]);
  const [payouts, setPayouts] = useState<any[]>([]);
  const [localReels, setLocalReels] = useState<any[]>([]);
  
  // PAGINATION CURSORS
  const [firstCreatorDoc, setFirstCreatorDoc] = useState<QueryDocumentSnapshot | null>(null);
  const [lastCreatorDoc, setLastCreatorDoc] = useState<QueryDocumentSnapshot | null>(null);
  const [firstPayoutDoc, setFirstPayoutDoc] = useState<QueryDocumentSnapshot | null>(null);
  const [lastPayoutDoc, setLastPayoutDoc] = useState<QueryDocumentSnapshot | null>(null);
  const [firstReelDoc, setFirstReelDoc] = useState<QueryDocumentSnapshot | null>(null);
  const [lastReelDoc, setLastReelDoc] = useState<QueryDocumentSnapshot | null>(null);

  // UI STATE
  const [activeTab, setActiveTab] = useState("daily-update");
  const [loading, setLoading] = useState<Record<string, boolean>>({ creators: false, payouts: false, reels: false });
  const [searchQuery, setSearchQuery] = useState("");
  const [viewingCreator, setViewingCreator] = useState<any>(null);
  const [viewingCreatorReels, setViewingCreatorReels] = useState<any[]>([]);
  const [viewingCreatorPayouts, setViewingCreatorPayouts] = useState<any[]>([]);
  const [loadingCreatorDetails, setLoadingCreatorDetails] = useState(false);
  const [editingFollowerId, setEditingFollowerId] = useState<string | null>(null);
  const [tempFollowerValue, setTempFollowerValue] = useState<string>("");
  const [payoutProcessingId, setPayoutProcessingId] = useState<string | null>(null);
  const [reelSearchQuery, setReelSearchQuery] = useState("");
  
  // SITE CONFIG
  const { data: profile } = useDoc<any>(db ? doc(db, "siteConfig", "traderProfile") : null);

  // MODALS
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<{type: 'reel' | 'creator', id: string, extraData?: any} | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // 1. SESSION AUTH CHECK
  useEffect(() => {
    const adminAuth = sessionStorage.getItem('adminAuth');
    if (adminAuth === 'true') {
      setIsAdmin(true);
    } else {
      router.push('/admin-secret');
    }
    setAuthChecked(true);
  }, [router]);

  // 2. LAZY LOAD DATA BASED ON TAB
  useEffect(() => {
    if (!isAdmin || !db) return;
    if (activeTab === 'creators' && creators.length === 0) fetchCreators('initial');
    if (activeTab === 'payouts' && payouts.length === 0) fetchPayouts('initial');
    if (activeTab === 'daily-update' && localReels.length === 0) fetchReels('initial');
  }, [activeTab, isAdmin, db]);

  // 3. FETCH CREATOR DETAILS WHEN MODAL OPENS
  useEffect(() => {
    const fetchCreatorDetails = async () => {
      if (!viewingCreator || !db) return;
      setLoadingCreatorDetails(true);
      setReelSearchQuery("");
      try {
        const handle = viewingCreator.handle?.toLowerCase().replace('@', '').trim();
        
        // Fetch Reels (Client-side sort to avoid composite index)
        const reelsQ = query(collection(db, "submissions"), where("instagramHandle", "==", handle));
        const reelsSnap = await getDocs(reelsQ);
        const reelsData = reelsSnap.docs.map(d => ({ ...d.data(), id: d.id }));
        reelsData.sort((a: any, b: any) => (b.submittedAt?.seconds || 0) - (a.submittedAt?.seconds || 0));
        setViewingCreatorReels(reelsData);

        // Fetch Payouts (Client-side sort to avoid composite index)
        const payoutsQ = query(collection(db, "payouts"), where("instagramHandle", "==", handle));
        const payoutsSnap = await getDocs(payoutsQ);
        const payoutsData = payoutsSnap.docs.map(d => ({ ...d.data(), id: d.id }));
        payoutsData.sort((a: any, b: any) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
        setViewingCreatorPayouts(payoutsData);
      } catch (err) {
        console.error("Error fetching creator details:", err);
      } finally {
        setLoadingCreatorDetails(false);
      }
    };

    if (viewingCreator) fetchCreatorDetails();
  }, [viewingCreator, db]);

  // DATA FETCHING WRAPPERS
  const fetchCreators = async (direction: 'initial' | 'next' | 'prev') => {
    if (!db) return;
    setLoading(prev => ({ ...prev, creators: true }));
    try {
      let q;
      if (direction === 'next' && lastCreatorDoc) {
        q = query(collection(db, "registrations"), orderBy("followerCount", "desc"), startAfter(lastCreatorDoc), limit(BATCH_SIZE));
      } else if (direction === 'prev' && firstCreatorDoc) {
        q = query(collection(db, "registrations"), orderBy("followerCount", "desc"), endBefore(firstCreatorDoc), limitToLast(BATCH_SIZE));
      } else {
        q = query(collection(db, "registrations"), orderBy("followerCount", "desc"), limit(BATCH_SIZE));
      }
      
      const snap = await getDocs(q);
      if (!snap.empty) {
        const docs = snap.docs;
        setCreators(docs.map(d => ({ ...d.data(), id: d.id })));
        setFirstCreatorDoc(docs[0]);
        setLastCreatorDoc(docs[docs.length - 1]);
      } else if (direction !== 'initial') {
        toast({ title: "End of registry reached." });
      }
    } catch (err) {
      toast({ variant: "destructive", title: "Fetch Error", description: "Registry link timeout." });
    } finally {
      setLoading(prev => ({ ...prev, creators: false }));
    }
  };

  const fetchPayouts = async (direction: 'initial' | 'next' | 'prev') => {
    if (!db) return;
    setLoading(prev => ({ ...prev, payouts: true }));
    try {
      let q;
      if (direction === 'next' && lastPayoutDoc) {
        q = query(collection(db, "payouts"), orderBy("createdAt", "desc"), startAfter(lastPayoutDoc), limit(BATCH_SIZE));
      } else if (direction === 'prev' && firstPayoutDoc) {
        q = query(collection(db, "payouts"), orderBy("createdAt", "desc"), endBefore(firstPayoutDoc), limitToLast(BATCH_SIZE));
      } else {
        q = query(collection(db, "payouts"), orderBy("createdAt", "desc"), limit(BATCH_SIZE));
      }

      const snap = await getDocs(q);
      if (!snap.empty) {
        const docs = snap.docs;
        setPayouts(docs.map(d => ({ ...d.data(), id: d.id })));
        setFirstPayoutDoc(docs[0]);
        setLastPayoutDoc(docs[docs.length - 1]);
      }
    } finally {
      setLoading(prev => ({ ...prev, payouts: false }));
    }
  };

  const fetchReels = async (direction: 'initial' | 'next' | 'prev') => {
    if (!db) return;
    setLoading(prev => ({ ...prev, reels: true }));
    try {
      let q;
      if (direction === 'next' && lastReelDoc) {
        q = query(collection(db, "submissions"), orderBy("submittedAt", "desc"), startAfter(lastReelDoc), limit(BATCH_SIZE));
      } else if (direction === 'prev' && firstReelDoc) {
        q = query(collection(db, "submissions"), orderBy("submittedAt", "desc"), endBefore(firstReelDoc), limitToLast(BATCH_SIZE));
      } else {
        q = query(collection(db, "submissions"), orderBy("submittedAt", "desc"), limit(BATCH_SIZE));
      }

      const snap = await getDocs(q);
      if (!snap.empty) {
        const docs = snap.docs;
        setLocalReels(docs.map(d => ({ ...d.data(), id: d.id })));
        setFirstReelDoc(docs[0]);
        setLastReelDoc(docs[docs.length - 1]);
      }
    } finally {
      setLoading(prev => ({ ...prev, reels: false }));
    }
  };

  // SEARCH FILTER (Local for current batch)
  const filteredCreators = useMemo(() => {
    const ADMIN_HANDLES = ['rama_krishna_reddy____', 'admin'];
    let list = creators.filter(c => !ADMIN_HANDLES.includes(c.handle?.toLowerCase()));
    if (!searchQuery) return list;
    const q = searchQuery.toLowerCase().replace(/^@/, '');
    return list.filter(c => (c.handle || "").toLowerCase().includes(q) || (c.creatorName || "").toLowerCase().includes(q));
  }, [creators, searchQuery]);

  const filteredViewingCreatorReels = useMemo(() => {
    if (!reelSearchQuery) return viewingCreatorReels;
    return viewingCreatorReels.filter(r => (r.reelUrl || "").toLowerCase().includes(reelSearchQuery.toLowerCase()));
  }, [viewingCreatorReels, reelSearchQuery]);

  const dailyGroups = useMemo(() => {
    const todayStart = new Date(); todayStart.setHours(0, 0, 0, 0);
    const sevenDaysAgo = new Date(todayStart); sevenDaysAgo.setDate(todayStart.getDate() - 7);
    const filtered = localReels.filter(r => r.instagramHandle?.toLowerCase().includes(searchQuery.toLowerCase().replace(/^@/, '')));
    return {
      today: filtered.filter(r => { 
        const t = r.submittedAt?.toMillis ? r.submittedAt.toMillis() : (r.submittedAt?.seconds ? r.submittedAt.seconds * 1000 : 0); 
        return t >= todayStart.getTime(); 
      }),
      recent: filtered.filter(r => { 
        const t = r.submittedAt?.toMillis ? r.submittedAt.toMillis() : (r.submittedAt?.seconds ? r.submittedAt.seconds * 1000 : 0); 
        return t < todayStart.getTime() && t >= sevenDaysAgo.getTime(); 
      }),
      expiring: filtered.filter(r => { 
        const t = r.submittedAt?.toMillis ? r.submittedAt.toMillis() : (r.submittedAt?.seconds ? r.submittedAt.seconds * 1000 : 0); 
        return t < sevenDaysAgo.getTime(); 
      })
    };
  }, [localReels, searchQuery]);

  // ACTIONS
  const handleMetricsUpdate = async (submissionId: string, views: string, likes: string) => {
    if (!db) return;
    try {
      await updateDoc(doc(db, 'submissions', submissionId), { 
        views: parseInt(views) || 0, 
        likes: parseInt(likes) || 0, 
        lastUpdated: serverTimestamp() 
      });
      toast({ title: "Metrics Synchronized" });
    } catch (e) { toast({ variant: "destructive", title: "Update Failed" }); }
  };

  const handleFollowerUpdate = async (creatorId: string, newValue: string) => {
    if (!db) return;
    try {
      await updateDoc(doc(db, "registrations", creatorId), { followerCount: parseInt(newValue) || 0, updatedAt: serverTimestamp() });
      toast({ title: "Followers Updated" });
      setEditingFollowerId(null);
      setCreators(prev => prev.map(c => c.id === creatorId ? { ...c, followerCount: parseInt(newValue) } : c));
    } catch (e) { toast({ variant: "destructive", title: "Sync Failed" }); }
  };

  const handlePayoutStatus = async (payoutId: string, newStatus: 'approved' | 'rejected' | 'paid') => {
    if (!db) return;
    setPayoutProcessingId(payoutId);
    try {
      await updateDoc(doc(db, "payouts", payoutId), { status: newStatus, processedAt: serverTimestamp() });
      toast({ title: `Status: ${newStatus}` });
      setPayouts(prev => prev.map(p => p.id === payoutId ? { ...p, status: newStatus } : p));
    } finally { setPayoutProcessingId(null); }
  };

  const handleToggleEligibility = async (creator: any) => {
    if (!db) return;
    const newStatus = !creator.isDisqualified;
    try {
      await updateDoc(doc(db, "registrations", creator.id), { isDisqualified: newStatus });
      toast({ title: newStatus ? "Creator Banned" : "Creator Restored" });
      setCreators(prev => prev.map(c => c.id === creator.id ? { ...c, isDisqualified: newStatus } : c));
      setViewingCreator(prev => ({ ...prev, isDisqualified: newStatus }));
    } catch (e) { toast({ variant: "destructive", title: "Action Failed" }); }
  };

  const executeDelete = async () => {
    if (!db || !itemToDelete) return;
    setIsDeleting(true);
    try {
      if (itemToDelete.type === 'reel') {
        await deleteDoc(doc(db, "submissions", itemToDelete.id));
        setLocalReels(prev => prev.filter(r => r.id !== itemToDelete.id));
      } else {
        await deleteDoc(doc(db, "registrations", itemToDelete.id));
        setCreators(prev => prev.filter(c => c.id !== itemToDelete.id));
      }
      toast({ title: "Record Deleted" });
    } finally { setIsDeleting(false); setItemToDelete(null); setIsDeleteDialogOpen(false); }
  };

  if (!authChecked || authLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-[#0a0a0a] text-primary gap-4">
        <Loader2 className="w-10 h-10 animate-spin" />
        <p className="text-[10px] font-black uppercase tracking-[0.3em]">Authenticating Dashboard Access...</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-16 max-w-7xl">
      <div className="flex flex-col md:flex-row items-center justify-between mb-10 gap-6">
        <div className="flex items-center gap-4">
          <Fingerprint className="w-12 h-12 text-primary" />
          <div>
            <h1 className="text-3xl font-headline font-bold uppercase tracking-tighter italic">Command Center</h1>
            <p className="text-[10px] text-primary uppercase font-black tracking-widest">Industrial Scale Data Hub</p>
          </div>
        </div>
        <div className="flex items-center gap-4 w-full md:w-auto">
          <div className="relative w-full md:w-64">
            <input placeholder="Filter current batch..." className="flex h-10 w-full rounded-md border border-white/10 bg-white/5 px-3 py-2 text-sm focus:outline-none pr-10" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
            {searchQuery && (<button onClick={() => setSearchQuery("")} className="absolute right-3 top-2.5 text-muted-foreground hover:text-white"><CloseIcon className="w-4 h-4" /></button>)}
          </div>
          <Button variant="outline" size="icon" onClick={() => window.location.reload()} className="border-white/10 shrink-0">
            <RefreshCw className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
        <TabsList className="bg-white/5 border border-white/10 p-1 flex overflow-x-auto no-scrollbar">
          <TabsTrigger value="daily-update" className="flex-1 py-2 text-[10px] uppercase font-bold">Daily Update</TabsTrigger>
          <TabsTrigger value="creators" className="flex-1 py-2 text-[10px] uppercase font-bold">Creators</TabsTrigger>
          <TabsTrigger value="payouts" className="flex-1 py-2 text-[10px] uppercase font-bold">Payouts</TabsTrigger>
          <TabsTrigger value="proofs" className="flex-1 py-2 text-[10px] uppercase font-bold">Proof Mgmt</TabsTrigger>
          <TabsTrigger value="settings" className="flex-1 py-2 text-[10px] uppercase font-bold">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="daily-update" className="space-y-12">
          {loading.reels && localReels.length === 0 ? (
            <div className="py-20 text-center flex flex-col items-center gap-4 opacity-50"><Loader2 className="animate-spin w-8 h-8 text-primary" /><p className="text-xs uppercase font-bold">Syncing Reels registry...</p></div>
          ) : (
            <>
              {[
                { id: 'today', title: 'Today', items: dailyGroups.today, color: 'border-primary' },
                { id: 'recent', title: 'Recent 7 Days', items: dailyGroups.recent, color: 'border-secondary' },
                { id: 'expiring', title: 'Legacy Registry', items: dailyGroups.expiring, color: 'border-muted' }
              ].map(group => (
                <div key={group.id} className="space-y-6">
                  <div className={`flex items-center gap-4 border-l-4 ${group.color} pl-4`}>
                    <h2 className="text-xl font-headline font-bold uppercase tracking-tight">{group.title} <span className="text-muted-foreground ml-2 font-code">({group.items.length})</span></h2>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {group.items.map((r, i) => (
                      <ReelAdminCard key={r.id} reel={r} index={i + 1} onUpdate={handleMetricsUpdate} onDelete={() => { setItemToDelete({type: 'reel', id: r.id}); setIsDeleteDialogOpen(true); }} />
                    ))}
                    {group.items.length === 0 && <p className="text-[10px] text-muted-foreground uppercase font-bold opacity-30 p-4">Queue Empty</p>}
                  </div>
                </div>
              ))}
              <div className="flex items-center justify-between pt-8 max-w-sm mx-auto">
                <Button variant="outline" size="sm" onClick={() => fetchReels('prev')} disabled={loading.reels || !firstReelDoc} className="uppercase text-[9px] font-bold"><ChevronLeft className="w-3 h-3 mr-1" /> Prev</Button>
                <span className="text-[9px] font-bold text-muted-foreground uppercase">Batch Registry</span>
                <Button variant="outline" size="sm" onClick={() => fetchReels('next')} disabled={loading.reels || !lastReelDoc} className="uppercase text-[9px] font-bold">Next <ChevronRight className="w-3 h-3 ml-1" /></Button>
              </div>
            </>
          )}
        </TabsContent>

        <TabsContent value="creators">
          <div className="glass-card overflow-hidden">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-white/5">
                  <TableRow>
                    <TableHead className="w-16">S.No</TableHead>
                    <TableHead>Handle/Name</TableHead>
                    <TableHead>Followers</TableHead>
                    <TableHead>WhatsApp</TableHead>
                    <TableHead>Eligibility</TableHead>
                    <TableHead className="text-right">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading.creators && creators.length === 0 ? (
                    <TableRow><TableCell colSpan={6} className="text-center py-20"><Loader2 className="animate-spin mx-auto w-8 h-8 mb-4 text-primary" /><p className="text-[10px] uppercase font-bold opacity-40">Syncing Industrial Registry...</p></TableCell></TableRow>
                  ) : filteredCreators.map((c, idx) => (
                    <TableRow key={c.id}>
                      <TableCell className="font-code text-muted-foreground">{idx + 1}</TableCell>
                      <TableCell>
                        <div className="font-bold">@{c.handle}</div>
                        <div className="text-[9px] text-muted-foreground uppercase tracking-widest">{c.creatorName}</div>
                      </TableCell>
                      <TableCell>
                        {editingFollowerId === c.id ? (
                          <div className="flex items-center gap-2">
                            <input type="number" value={tempFollowerValue} onChange={e => setTempFollowerValue(e.target.value)} className="w-20 h-8 bg-white/10 border-white/20 rounded px-2 font-code" autoFocus />
                            <Button size="icon" variant="ghost" className="h-8 w-8 text-green-500" onClick={() => handleFollowerUpdate(c.id, tempFollowerValue)}><Check className="w-4 h-4" /></Button>
                          </div>
                        ) : (
                          <button onClick={() => { setEditingFollowerId(c.id); setTempFollowerValue(c.followerCount?.toString() || "0"); }} className="font-code text-primary font-bold hover:underline">
                            {(c.followerCount || 0).toLocaleString()}
                          </button>
                        )}
                      </TableCell>
                      <TableCell className="font-code text-xs">
                        <a href={`https://wa.me/${c.phoneNumber?.replace(/\D/g, '')}`} target="_blank" className="text-secondary hover:underline">
                          {c.phoneNumber || '---'}
                        </a>
                      </TableCell>
                      <TableCell>
                        {c.isDisqualified ? <Badge variant="destructive" className="text-[8px] uppercase">Banned</Badge> : <Badge className="bg-green-500/10 text-green-500 text-[8px] uppercase">Eligible</Badge>}
                      </TableCell>
                      <TableCell className="text-right flex justify-end gap-2">
                        <Button variant="ghost" size="icon" asChild className="hover:text-primary"><a href={`https://instagram.com/${c.handle?.replace('@', '')}`} target="_blank"><Instagram className="w-4 h-4" /></a></Button>
                        <Button variant="ghost" size="icon" onClick={() => setViewingCreator(c)}><Eye className="w-4 h-4" /></Button>
                        <Button variant="ghost" size="icon" className="text-destructive" onClick={() => { setItemToDelete({type: 'creator', id: c.id}); setIsDeleteDialogOpen(true); }}><Trash2 className="w-4 h-4" /></Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            <div className="p-4 border-t border-white/5 flex items-center justify-between">
               <Button variant="outline" size="sm" onClick={() => fetchCreators('prev')} disabled={loading.creators || !firstCreatorDoc} className="uppercase text-[9px] font-bold"><ChevronLeft className="w-3 h-3 mr-1" /> Prev</Button>
               <span className="text-[9px] font-bold text-muted-foreground uppercase">Batch Records</span>
               <Button variant="outline" size="sm" onClick={() => fetchCreators('next')} disabled={loading.creators || !lastCreatorDoc} className="uppercase text-[9px] font-bold">Next <ChevronRight className="w-3 h-3 ml-1" /></Button>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="payouts">
          <div className="glass-card overflow-hidden">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-white/5">
                  <TableRow>
                    <TableHead className="w-16">S.No</TableHead>
                    <TableHead>Creator</TableHead>
                    <TableHead>Account</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading.payouts && payouts.length === 0 ? (
                    <TableRow><TableCell colSpan={6} className="text-center py-20"><Loader2 className="animate-spin mx-auto w-8 h-8 text-primary" /></TableCell></TableRow>
                  ) : payouts.map((p, idx) => (
                    <TableRow key={p.id}>
                      <TableCell className="font-code text-muted-foreground">{idx + 1}</TableCell>
                      <TableCell className="font-bold">@{p.instagramHandle}</TableCell>
                      <TableCell className="text-xs font-code opacity-60">{p.accountDetails}</TableCell>
                      <TableCell className="text-primary font-bold">₹{p.amount}</TableCell>
                      <TableCell><Badge className="uppercase text-[8px]">{p.status}</Badge></TableCell>
                      <TableCell className="text-right">
                        {p.status === 'pending' && (
                          <div className="flex justify-end gap-2">
                            <Button size="sm" className="bg-green-600 text-white text-[9px] font-bold" onClick={() => handlePayoutStatus(p.id, 'paid')}>Mark Paid</Button>
                            <Button size="sm" variant="destructive" className="text-[9px] font-bold" onClick={() => handlePayoutStatus(p.id, 'rejected')}>Reject</Button>
                          </div>
                        )}
                        {p.status === 'paid' && <Check className="w-4 h-4 text-green-500 ml-auto" />}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            <div className="p-4 border-t border-white/5 flex items-center justify-between">
               <Button variant="outline" size="sm" onClick={() => fetchPayouts('prev')} disabled={loading.payouts || !firstPayoutDoc} className="uppercase text-[9px] font-bold"><ChevronLeft className="w-3 h-3 mr-1" /> Prev</Button>
               <span className="text-[9px] font-bold text-muted-foreground uppercase">Batch Registry</span>
               <Button variant="outline" size="sm" onClick={() => fetchPayouts('next')} disabled={loading.payouts || !lastPayoutDoc} className="uppercase text-[9px] font-bold">Next <ChevronRight className="w-3 h-3 ml-1" /></Button>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="proofs"><ProofGallery /></TabsContent>
        
        <TabsContent value="settings">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="glass-card p-6 space-y-4">
              <h3 className="font-headline font-bold text-xl flex items-center gap-2 text-primary"><Zap className="w-5 h-5" /> Config Synchronizer</h3>
              <div className="space-y-4">
                <div className="space-y-1"><Label className="text-[10px] font-bold">Trader Bio</Label><Textarea defaultValue={profile?.bio} id="profile-bio" className="bg-white/5 border-white/10" /></div>
                <Button className="w-full bg-primary text-black font-bold h-12 uppercase text-[10px] neon-gold">Push Global Update</Button>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* CREATOR DETAIL MODAL */}
      <Dialog open={!!viewingCreator} onOpenChange={o => !o && setViewingCreator(null)}>
        <DialogContent className="glass-card bg-[#131314] max-w-5xl max-h-[90vh] flex flex-col p-0 border-white/10">
           <DialogHeader className="p-6 border-b border-white/5 flex flex-row items-center justify-between">
              <div>
                <DialogTitle className="text-2xl font-headline font-bold text-white flex items-center gap-3">
                  @{viewingCreator?.handle}
                  {viewingCreator?.isDisqualified && <Badge variant="destructive">BANNED</Badge>}
                </DialogTitle>
                <DialogDescription className="text-xs uppercase tracking-widest font-bold text-muted-foreground mt-1">{viewingCreator?.creatorName}</DialogDescription>
              </div>
              <div className="flex gap-3">
                <Button 
                  variant={viewingCreator?.isDisqualified ? "outline" : "destructive"} 
                  size="sm" 
                  onClick={() => handleToggleEligibility(viewingCreator)}
                  className="text-[10px] font-black uppercase tracking-widest"
                >
                  {viewingCreator?.isDisqualified ? "Reinstate Account" : "Disqualify Account"}
                </Button>
              </div>
           </DialogHeader>

           <ScrollArea className="flex-1">
             <div className="p-6 space-y-10">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                   <div className="p-4 bg-white/5 rounded-xl border border-white/5">
                      <p className="text-[10px] font-bold text-muted-foreground uppercase mb-1">Followers</p>
                      <p className="text-xl font-code font-bold text-primary">{(viewingCreator?.followerCount || 0).toLocaleString()}</p>
                   </div>
                   <div className="p-4 bg-white/5 rounded-xl border border-white/5">
                      <p className="text-[10px] font-bold text-muted-foreground uppercase mb-1">WhatsApp</p>
                      <p className="text-xs font-code text-white">{viewingCreator?.phoneNumber || '---'}</p>
                   </div>
                   <div className="p-4 bg-white/5 rounded-xl border border-white/5">
                      <p className="text-[10px] font-bold text-muted-foreground uppercase mb-1">Total Reels</p>
                      <p className="text-xl font-code font-bold text-white">{viewingCreatorReels.length}</p>
                   </div>
                   <div className="p-4 bg-secondary/10 rounded-xl border border-secondary/20">
                      <p className="text-[10px] font-bold text-secondary uppercase mb-1">Paid Amount</p>
                      <p className="text-xl font-code font-bold text-white">₹{viewingCreatorPayouts.filter(p => p.status === 'paid').reduce((acc, p) => acc + (p.amount || 0), 0)}</p>
                   </div>
                </div>

                <div className="space-y-4">
                   <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <h3 className="text-sm font-headline font-bold text-white flex items-center gap-2">
                        <Play className="w-4 h-4 text-primary" /> Submission Registry ({viewingCreatorReels.length} reels)
                      </h3>
                      <div className="relative w-full md:w-64">
                        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input 
                          placeholder="Search reel URL..." 
                          className="pl-9 h-9 bg-white/5 border-white/10 text-xs"
                          value={reelSearchQuery}
                          onChange={e => setReelSearchQuery(e.target.value)}
                        />
                      </div>
                   </div>
                   <div className="glass-card overflow-hidden">
                      <Table>
                        <TableHeader className="bg-white/5">
                          <TableRow>
                            <TableHead className="text-[9px] uppercase">Reel Link</TableHead>
                            <TableHead className="text-[9px] uppercase">Views</TableHead>
                            <TableHead className="text-[9px] uppercase">Likes</TableHead>
                            <TableHead className="text-[9px] uppercase">Earned</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {loadingCreatorDetails ? <TableRow><TableCell colSpan={4} className="text-center py-10"><Loader2 className="animate-spin mx-auto" /></TableCell></TableRow> : 
                           filteredViewingCreatorReels.length === 0 ? <TableRow><TableCell colSpan={4} className="text-center py-10 text-muted-foreground text-xs italic">No matching reels found.</TableCell></TableRow> : 
                           filteredViewingCreatorReels.map((r) => {
                             let earned = 0;
                             if (r.views >= 100000) earned = 1500;
                             else if (r.views >= 50000) earned = 500;
                             return (
                               <TableRow key={r.id}>
                                 <TableCell className="max-w-[300px] truncate"><a href={r.reelUrl} target="_blank" className="text-xs text-secondary hover:underline flex items-center gap-1"><ExternalLink className="w-3 h-3" /> {r.reelUrl}</a></TableCell>
                                 <TableCell className="font-code text-white">{(r.views || 0).toLocaleString()}</TableCell>
                                 <TableCell className="font-code text-muted-foreground">{(r.likes || 0).toLocaleString()}</TableCell>
                                 <TableCell className="font-code text-primary font-bold">{earned > 0 ? `₹${earned}` : '---'}</TableCell>
                               </TableRow>
                             )
                           })}
                        </TableBody>
                      </Table>
                   </div>
                </div>

                <div className="space-y-4 pb-6">
                   <h3 className="text-sm font-headline font-bold text-white flex items-center gap-2"><Wallet className="w-4 h-4 text-secondary" /> Payout Ledger ({viewingCreatorPayouts.length} entries)</h3>
                   <div className="glass-card overflow-hidden">
                      <Table>
                        <TableHeader className="bg-white/5">
                          <TableRow>
                            <TableHead className="text-[9px] uppercase">Date</TableHead>
                            <TableHead className="text-[9px] uppercase">Amount</TableHead>
                            <TableHead className="text-[9px] uppercase">Status</TableHead>
                            <TableHead className="text-[9px] uppercase">Action</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {loadingCreatorDetails ? <TableRow><TableCell colSpan={4} className="text-center py-10"><Loader2 className="animate-spin mx-auto" /></TableCell></TableRow> : 
                           viewingCreatorPayouts.length === 0 ? <TableRow><TableCell colSpan={4} className="text-center py-10 text-muted-foreground text-xs italic">No payout history found.</TableCell></TableRow> : 
                           viewingCreatorPayouts.map((p) => (
                             <TableRow key={p.id}>
                               <TableCell className="text-xs text-white">{p.createdAt?.seconds ? new Date(p.createdAt.seconds * 1000).toLocaleDateString() : 'Processing'}</TableCell>
                               <TableCell className="font-code font-bold text-primary">₹{p.amount}</TableCell>
                               <TableCell><Badge className="text-[8px] uppercase">{p.status}</Badge></TableCell>
                               <TableCell>
                                 {p.status === 'pending' && <Button size="sm" className="h-7 text-[8px] bg-green-600" onClick={() => handlePayoutStatus(p.id, 'paid')}>Mark Paid</Button>}
                               </TableCell>
                             </TableRow>
                           ))}
                        </TableBody>
                      </Table>
                   </div>
                </div>
             </div>
           </ScrollArea>
        </DialogContent>
      </Dialog>

      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent className="glass-card bg-[#131314] border-destructive/20">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-destructive font-headline font-bold uppercase">Authorize Purge</AlertDialogTitle>
            <AlertDialogDescription>Permanent removal of cloud record. This cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={executeDelete} className="bg-destructive text-white">{isDeleting ? <Loader2 className="animate-spin" /> : "Confirm Delete"}</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function ReelAdminCard({ reel, index, onUpdate, onDelete }: { reel: any, index: number, onUpdate: (id: string, v: string, l: string) => Promise<void>, onDelete: () => void }) {
  const [v, setV] = useState(reel.views?.toString() || "0");
  const [l, setL] = useState(reel.likes?.toString() || "0");
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    await onUpdate(reel.id, v, l);
    setSaving(false);
  };

  return (
    <div className="glass-card overflow-hidden border-white/10 flex flex-col h-full group">
      <div className="relative aspect-video bg-black/40">
        {reel.thumbnailUrl ? <img src={reel.thumbnailUrl} className="w-full h-full object-cover opacity-60" alt="Thumb" /> : <div className="w-full h-full flex items-center justify-center"><Play className="w-8 h-8 opacity-20" /></div>}
        <div className="absolute top-2 right-2"><Button variant="ghost" size="icon" className="h-8 w-8 text-destructive bg-black/40 hover:bg-destructive" onClick={onDelete}><Trash2 className="w-4 h-4" /></Button></div>
        <div className="absolute top-2 left-2"><Badge className="bg-primary text-black font-bold text-[8px] uppercase">Entry #{index}</Badge></div>
      </div>
      <div className="p-4 space-y-4 flex-grow flex flex-col">
        <div>
          <p className="text-xs font-bold text-primary">@{reel.instagramHandle}</p>
          <p className="text-[10px] text-muted-foreground line-clamp-1 italic mt-1">{reel.description}</p>
        </div>
        <div className="grid grid-cols-2 gap-3 mt-auto">
          <div className="space-y-1"><Label className="text-[8px] uppercase font-bold text-muted-foreground">Views</Label><input type="number" value={v} onChange={e => setV(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded h-8 px-2 font-code text-xs text-white" /></div>
          <div className="space-y-1"><Label className="text-[8px] uppercase font-bold text-muted-foreground">Likes</Label><input type="number" value={l} onChange={e => setL(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded h-8 px-2 font-code text-xs text-white" /></div>
        </div>
        <Button onClick={handleSave} disabled={saving} className="w-full bg-primary text-black font-bold h-10 uppercase text-[9px]">
          {saving ? <Loader2 className="animate-spin w-3 h-3" /> : "Sync Metrics"}
        </Button>
      </div>
    </div>
  );
}
