
'use client';

import { useEffect, useState } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, onSnapshot } from 'firebase/firestore';
import { useAuth, useFirestore } from '../provider';

export interface HubUser {
  uid: string;
  displayName: string;
  handle: string;
  email: string;
  isAdmin?: boolean;
}

export function useUser() {
  const auth = useAuth();
  const db = useFirestore();
  const [user, setUser] = useState<HubUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAdmin = () => {
      if (typeof window === 'undefined') return null;
      const isAdminSession = sessionStorage.getItem('adminAuth') === 'true';
      if (isAdminSession) {
        return { 
          uid: 'admin-session-active', 
          displayName: 'System Administrator', 
          handle: 'ADMIN', 
          isAdmin: true,
          email: 'admin@aryangold.hub'
        };
      }
      return null;
    };

    const checkMock = () => {
      if (typeof window === 'undefined') return null;
      const mock = localStorage.getItem('mock_user');
      if (mock) {
        try {
          return JSON.parse(mock);
        } catch (e) {
          return null;
        }
      }
      return null;
    };

    const refreshUser = () => {
      // 1. Priority check for Admin session
      const admin = checkAdmin();
      if (admin) {
        setUser(admin);
        setLoading(false);
        return;
      }

      // 2. Standard Firebase Auth logic
      if (!auth || !db) {
        setUser(checkMock());
        setLoading(false);
        return;
      }

      const unsubscribeAuth = onAuthStateChanged(auth, (firebaseUser) => {
        if (firebaseUser) {
          const userRef = doc(db, 'users', firebaseUser.uid);
          const unsubscribeDoc = onSnapshot(userRef, (docSnap) => {
            const currentAdmin = checkAdmin();
            if (currentAdmin) {
              setUser(currentAdmin);
            } else if (docSnap.exists()) {
              setUser({
                uid: firebaseUser.uid,
                ...(docSnap.data() as any),
                isAdmin: (docSnap.data() as any).isAdmin || (docSnap.data() as any).role === 'admin'
              });
            } else {
              setUser({
                uid: firebaseUser.uid,
                displayName: firebaseUser.displayName || 'Creator',
                handle: '',
                email: firebaseUser.email || '',
                isAdmin: false
              });
            }
            setLoading(false);
          }, () => {
            setLoading(false);
          });

          return () => unsubscribeDoc();
        } else {
          setUser(checkAdmin() || checkMock());
          setLoading(false);
        }
      });

      return unsubscribeAuth;
    };

    const unsubscribe = refreshUser();

    const handleSessionChange = () => {
      const admin = checkAdmin();
      if (admin) setUser(admin);
      else setUser(checkMock());
    };

    window.addEventListener('mock-auth-change', handleSessionChange);
    
    return () => {
      if (unsubscribe) unsubscribe();
      window.removeEventListener('mock-auth-change', handleSessionChange);
    };
  }, [auth, db]);

  return { user, loading };
}
