'use server';

/**
 * @fileOverview Server action to verify administrative credentials against environment variables.
 * This ensures passwords are never exposed to the client-side bundle.
 */

export async function verifyAdminCredentials(username: string, pass: string) {
  const admins = [
    { id: process.env.ADMIN_1_ID, pass: process.env.ADMIN_1_PASS },
    { id: process.env.ADMIN_2_ID, pass: process.env.ADMIN_2_PASS },
    { id: process.env.ADMIN_3_ID, pass: process.env.ADMIN_3_PASS },
    { id: process.env.ADMIN_4_ID, pass: process.env.ADMIN_4_PASS },
    { id: process.env.ADMIN_5_ID, pass: process.env.ADMIN_5_PASS },
  ];

  const admin = admins.find(a => a.id === username && a.pass === pass);
  
  if (admin && admin.id) {
    return {
      success: true,
      user: {
        uid: "admin-" + admin.id,
        displayName: "System Administrator",
        handle: admin.id,
        isAdmin: true,
        email: "admin@aryangold.hub"
      }
    };
  }
  
  return { success: false };
}
