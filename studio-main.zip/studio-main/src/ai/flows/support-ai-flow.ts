'use server';
/**
 * @fileOverview An AI support agent for Aryan Gold Hub.
 *
 * - supportAI - A function that handles user support queries.
 * - SupportAIInput - The input type for the supportAI function.
 * - SupportAIOutput - The return type for the supportAI function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const SupportAIInputSchema = z.object({
  query: z.string().describe("The user's question about the Aryan Gold Hub."),
});
export type SupportAIInput = z.infer<typeof SupportAIInputSchema>;

const SupportAIOutputSchema = z.object({
  answer: z.string().describe('The helpful, concise answer provided to the user.'),
});
export type SupportAIOutput = z.infer<typeof SupportAIOutputSchema>;

export async function supportAI(input: SupportAIInput): Promise<SupportAIOutput> {
  return supportAIFlow(input);
}

const prompt = ai.definePrompt({
  name: 'supportAIPrompt',
  input: { schema: SupportAIInputSchema },
  output: { schema: SupportAIOutputSchema },
  prompt: `You are a helpful support assistant for Aryan Gold Hub website. Answer all questions about: registration, reels submission, follower requirements, payout process, milestone rewards, rankings, weekly war, content vault, and general website features. Be friendly and helpful. NEVER reveal any admin information, admin credentials, admin dashboard details, payment details, or any backend/database information. If asked about admin things, say you cannot help with that.

=== OFFICIAL HUB RULES & CONTEXT ===
- How to register: Click "Join Hub", fill in your Legal Name, Instagram ID (username), WhatsApp Number, and Email.
- Follower requirements: You must have minimum 1,000 followers on your fan page to be eligible for cash rewards and reel incentives.
- How to submit reels: Go to the Weekly War page or your Dashboard to deploy your Instagram Reel links.
- Cash Incentives (Performance Bonus):
  * 50,000 views = ₹500 cash
  * 1,00,000 views = ₹1,500 cash
- Milestone Rewards:
  * 1K followers → VIP Group Access OR Reel Incentives Unlocked 🔓
  * 10K followers → 2 Funded Trading Accounts OR ₹10,000
  * 50K followers → iPhone or MacBook
  * 100K followers → International Trip with Aryan Sir personally
- Payout Process: Admin team updates views daily (3:00 PM – 5:00 PM IST). Rewards are processed within 3-5 business days after threshold verification and sent via UPI.
- Following Rule: Your fan page must follow maximum 50 accounts to stay eligible.
- Weekly War: A weekly competition where top reels earn bonus visibility and special prizes.
- Support Email: noims108a@gmail.com

Answer all questions accurately based ONLY on this information. Answer in 2-3 sentences max. If the question is unrelated, say "I can only help with Aryan Gold Hub related queries."

User Question: {{{query}}}`,
});

const supportAIFlow = ai.defineFlow(
  {
    name: 'supportAIFlow',
    inputSchema: SupportAIInputSchema,
    outputSchema: SupportAIOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    if (!output) throw new Error('Failed to generate support response.');
    return output;
  }
);
