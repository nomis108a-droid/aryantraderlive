
"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Lock, ShieldAlert, Loader2, ArrowLeft } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import Link from "next/link"

export default function AdminSecretPage() {
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(false)
  const { toast } = useToast()
  const router = useRouter()

  const MASTER_PASSCODE = "93463962569392846256"

  useEffect(() => {
    if (sessionStorage.getItem('adminAuth') === 'true') {
      router.push("/admin-dashboard")
    }
  }, [router])

  const handleUnlock = () => {
    setLoading(true)
    setError(false)

    // Simulate verification delay
    setTimeout(() => {
      if (password === MASTER_PASSCODE) {
        sessionStorage.setItem('adminAuth', 'true')
        window.dispatchEvent(new Event('mock-auth-change'))
        toast({
          title: "Session Authorized",
          description: "Welcome back, Administrator. Redirecting...",
        })
        router.push("/admin-dashboard")
      } else {
        setError(true)
        toast({
          variant: "destructive",
          title: "Verification Failed",
          description: "The passcode entered is not recognized by the hub.",
        })
      }
      setLoading(false)
    }, 800)
  }

  return (
    <div className="container mx-auto px-4 min-h-[80vh] flex items-center justify-center">
      <div className="glass-card border-primary/30 max-w-md w-full bg-[#131314] p-10 space-y-8 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-primary animate-pulse" />
        
        <div className="flex flex-col items-center gap-6">
          <div className="w-20 h-20 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center shadow-[0_0_20px_rgba(255,215,0,0.1)]">
            <Lock className="w-10 h-10 text-primary" />
          </div>
          <div className="text-center space-y-2">
            <h1 className="text-3xl font-headline font-bold text-white uppercase tracking-tighter">Command Access</h1>
            <p className="text-[10px] text-muted-foreground uppercase tracking-[0.4em] font-black">Restricted Management Hub</p>
          </div>
        </div>

        <div className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="admin-pass" className="text-[10px] font-bold uppercase tracking-widest text-primary ml-1">Master Authorization Code</Label>
            <div className="relative">
              <Input 
                id="admin-pass"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className={`bg-white/5 border-white/10 text-center tracking-[0.5em] font-bold h-14 text-xl ${error ? 'border-destructive ring-1 ring-destructive' : 'focus:border-primary/50'}`}
                placeholder="••••••••••••"
                onKeyDown={(e) => e.key === 'Enter' && handleUnlock()}
                autoFocus
              />
              {error && (
                <div className="absolute -bottom-6 left-0 w-full text-center">
                   <p className="text-[9px] text-destructive font-black uppercase tracking-widest flex items-center justify-center gap-1">
                     <ShieldAlert className="w-3 h-3" /> Critical: Access Denied
                   </p>
                </div>
              )}
            </div>
          </div>

          <Button 
            onClick={handleUnlock}
            disabled={loading || !password}
            className="w-full bg-primary text-black font-black h-14 uppercase tracking-[0.2em] text-xs neon-gold hover:scale-[1.02] transition-transform"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : "Authorize Session"}
          </Button>
        </div>

        <div className="pt-4 flex justify-center">
          <Link href="/" className="flex items-center gap-2 text-[10px] font-bold text-muted-foreground hover:text-white transition-colors uppercase tracking-widest">
            <ArrowLeft className="w-3 h-3" /> Return to Safety
          </Link>
        </div>
      </div>
    </div>
  )
}
