
"use client"

import Link from "next/link"
import { useState, useEffect } from "react"
import { useUser, useFirestore, useAuth } from "@/firebase"
import { collection, query, where, getDocs } from "firebase/firestore"
import { signInWithEmailAndPassword, sendPasswordResetEmail, signOut } from "firebase/auth"
import { Button } from "@/components/ui/button"
import { Menu, X, LogOut, LayoutDashboard, Wallet, ChevronDown, LogIn, Loader2, Headset, FileVideo, ShieldCheck, Gavel, Lock, Instagram, Mail } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export function Navbar() {
  const { user } = useUser()
  const db = useFirestore()
  const auth = useAuth()
  
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [showLoginDialog, setShowLoginDialog] = useState(false)
  const [showForgotDialog, setShowForgotDialog] = useState(false)
  
  const [loginData, setLoginData] = useState({ handle: "", password: "" })
  const [forgotEmail, setForgotEmail] = useState("")
  
  const [isLoggingIn, setIsLoggingIn] = useState(false)
  const [isSendingReset, setIsSendingReset] = useState(false)
  
  const { toast } = useToast()

  useEffect(() => {
    const handleTrigger = () => setShowLoginDialog(true);
    window.addEventListener('trigger-login-dialog', handleTrigger);
    return () => window.removeEventListener('trigger-login-dialog', handleTrigger);
  }, []);

  const handleAuthLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!db || !auth) return

    setIsLoggingIn(true)
    const handle = loginData.handle.replace('@', '').toLowerCase().trim()
    
    try {
      const usersRef = collection(db, "users")
      const q = query(usersRef, where("handle", "==", handle))
      const snapshot = await getDocs(q)
      
      if (snapshot.empty) {
        toast({ variant: "destructive", title: "Account Not Found" })
      } else {
        const userData = snapshot.docs[0].data()
        await signInWithEmailAndPassword(auth, userData.email, loginData.password)
        setShowLoginDialog(false)
        setLoginData({ handle: "", password: "" })
        toast({ title: "Authorized", description: `Welcome back, @${handle}` })
      }
    } catch (err: any) {
      toast({ variant: "destructive", title: "Login Failed", description: "Invalid credentials. Please try again." })
    } finally {
      setIsLoggingIn(false)
    }
  }

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!auth || !forgotEmail) return

    setIsSendingReset(true)
    try {
      await sendPasswordResetEmail(auth, forgotEmail)
      toast({
        title: "Reset Link Sent",
        description: "Password reset link sent to your Gmail! Check your inbox.",
      })
      setShowForgotDialog(false)
      setForgotEmail("")
      setShowLoginDialog(true)
    } catch (err: any) {
      let errorMessage = "Failed to send reset email. Please try again."
      if (err.code === 'auth/user-not-found') errorMessage = "No account found with this email."
      toast({ variant: "destructive", title: "Reset Failed", description: errorMessage })
    } finally {
      setIsSendingReset(false)
    }
  }

  const handleLogout = async () => {
    if (!auth) return
    await signOut(auth)
    sessionStorage.removeItem('adminAuth')
    localStorage.removeItem('mock_user')
    window.dispatchEvent(new Event('mock-auth-change'))
    toast({ title: "Signed Out" })
    setIsMobileMenuOpen(false)
    window.location.href = "/";
  }

  const isAdmin = user?.handle === 'ADMIN';

  return (
    <>
      <nav className="sticky top-0 z-50 w-full border-b border-white/10 bg-[#131314]/80 backdrop-blur-md">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <span className="font-headline text-base md:text-xl font-bold gold-gradient-text tracking-tight uppercase">Aryan Gold Hub</span>
          </Link>

          <div className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors">Home</Link>
            <Link href="/rules" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors flex items-center gap-1"><Gavel className="w-3.5 h-3.5" /> Rules</Link>
            <Link href="/leaderboard" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors">Rankings</Link>
            <Link href="/competition" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors">Weekly War</Link>
            <Link href="/content-vault" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors flex items-center gap-1"><FileVideo className="w-3.5 h-3.5" /> Vault</Link>
            <Link href="/support" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors flex items-center gap-1"><Headset className="w-3.5 h-3.5" /> Support</Link>
            
            {user ? (
              <div className="flex items-center gap-2">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button className="flex items-center gap-2 pl-2 pr-2 py-1 rounded-full hover:bg-white/5 border border-white/5 transition-all">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs uppercase ${isAdmin ? 'bg-primary text-black' : 'bg-primary/20 text-primary'}`}>
                        {user.handle?.[0] || 'U'}
                      </div>
                      <span className={`text-xs font-bold ${isAdmin ? 'text-primary' : 'text-secondary'}`}>{isAdmin ? 'ADMIN' : `@${user.handle}`}</span>
                      <ChevronDown className="w-4 h-4 text-muted-foreground" />
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="glass-card w-56 border-white/10 text-white mt-2">
                    <DropdownMenuLabel className="uppercase text-[10px] tracking-widest text-muted-foreground">
                      {isAdmin ? 'System Session Active' : `ID: ${user.uid.slice(0, 8)}`}
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator className="bg-white/10" />
                    {!isAdmin && (
                      <>
                        <Link href="/dashboard"><DropdownMenuItem className="cursor-pointer"><LayoutDashboard className="w-4 h-4 mr-2" /> Dashboard</DropdownMenuItem></Link>
                        <Link href="/payout"><DropdownMenuItem className="cursor-pointer"><Wallet className="w-4 h-4 mr-2" /> My Earnings</DropdownMenuItem></Link>
                        <DropdownMenuSeparator className="bg-white/10" />
                      </>
                    )}
                    {isAdmin && (
                      <Link href="/admin-dashboard"><DropdownMenuItem className="cursor-pointer"><ShieldCheck className="w-4 h-4 mr-2" /> Command Center</DropdownMenuItem></Link>
                    )}
                    <DropdownMenuItem onClick={handleLogout} className="text-red-400 cursor-pointer font-bold"><LogOut className="w-4 h-4 mr-2" /> Log Out</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            ) : (
              <div className="flex items-center gap-3">
                <Button size="sm" variant="ghost" onClick={() => setShowLoginDialog(true)} className="text-xs font-bold uppercase hover:text-primary">Login</Button>
                <Link href="/register"><Button size="sm" className="neon-gold bg-primary text-black font-bold h-9 uppercase text-[10px] tracking-widest">Join Hub</Button></Link>
              </div>
            )}
          </div>

          <button className="md:hidden text-muted-foreground p-2" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {isMobileMenuOpen && (
          <div className="md:hidden absolute top-16 left-0 w-full bg-[#131314] border-b border-white/10 py-8 px-6 flex flex-col gap-6 animate-in slide-in-from-top duration-300">
            <Link href="/" className="text-xl font-headline font-bold" onClick={() => setIsMobileMenuOpen(false)}>Home</Link>
            <Link href="/rules" className="text-xl font-headline font-bold" onClick={() => setIsMobileMenuOpen(false)}>Rules</Link>
            <Link href="/leaderboard" className="text-xl font-headline font-bold" onClick={() => setIsMobileMenuOpen(false)}>Rankings</Link>
            <Link href="/competition" className="text-xl font-headline font-bold" onClick={() => setIsMobileMenuOpen(false)}>Weekly War</Link>
            {user ? (
              <div className="flex flex-col gap-4 pt-4 border-t border-white/10">
                {!isAdmin && (
                  <>
                    <Link href="/dashboard" className="text-lg font-bold text-secondary" onClick={() => setIsMobileMenuOpen(false)}>Dashboard</Link>
                    <Link href="/payout" className="text-lg font-bold text-secondary" onClick={() => setIsMobileMenuOpen(false)}>Earnings</Link>
                  </>
                )}
                {isAdmin && (
                  <Link href="/admin-dashboard" className="text-lg font-bold text-primary" onClick={() => setIsMobileMenuOpen(false)}>Admin Panel</Link>
                )}
                <Button onClick={handleLogout} variant="outline" className="justify-start border-white/10 text-red-400 font-bold"><LogOut className="w-4 h-4 mr-2" /> Log Out</Button>
              </div>
            ) : (
              <div className="flex flex-col gap-4 pt-4 border-t border-white/10">
                <Button onClick={() => { setShowLoginDialog(true); setIsMobileMenuOpen(false); }} className="w-full h-12 bg-white/5 text-white border-white/10 font-bold">Login</Button>
                <Link href="/register" onClick={() => setIsMobileMenuOpen(false)}><Button className="w-full h-12 bg-primary text-black font-bold">Register Now</Button></Link>
              </div>
            )}
          </div>
        )}
      </nav>

      {/* Login Dialog */}
      <Dialog open={showLoginDialog} onOpenChange={setShowLoginDialog}>
        <DialogContent className="glass-card border-primary/20 max-w-[90vw] sm:max-w-md bg-[#131314]">
          <DialogHeader>
            <DialogTitle className="text-2xl font-headline font-bold text-primary uppercase italic">Creator Login</DialogTitle>
            <DialogDescription className="text-xs text-muted-foreground uppercase tracking-widest pt-2">Authorized Sync Hub</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleAuthLogin} className="space-y-6 py-4">
            <div className="space-y-2">
              <Label className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">Instagram ID</Label>
              <div className="relative">
                <Instagram className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input placeholder="@handle" className="pl-10 bg-white/5 border-white/10 h-12" required value={loginData.handle} onChange={(e) => setLoginData({...loginData, handle: e.target.value})} />
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">Password</Label>
                <button type="button" onClick={() => { setShowLoginDialog(false); setShowForgotDialog(true); }} className="text-[10px] font-bold text-primary hover:underline uppercase">Forgot?</button>
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input type="password" placeholder="••••••••" className="pl-10 bg-white/5 border-white/10 h-12" required value={loginData.password} onChange={(e) => setLoginData({...loginData, password: e.target.value})} />
              </div>
            </div>
            <Button type="submit" disabled={isLoggingIn} className="w-full bg-primary text-black font-black h-12 uppercase tracking-widest text-xs neon-gold">
              {isLoggingIn ? <Loader2 className="animate-spin" /> : "Access Profile"}
            </Button>
            <p className="text-center text-[10px] text-muted-foreground uppercase">New creator? <Link href="/register" className="text-primary font-bold hover:underline" onClick={() => setShowLoginDialog(false)}>Register here</Link></p>
          </form>
        </DialogContent>
      </Dialog>

      {/* Forgot Password Dialog */}
      <Dialog open={showForgotDialog} onOpenChange={setShowForgotDialog}>
        <DialogContent className="glass-card border-primary/20 max-w-[90vw] sm:max-w-md bg-[#131314]">
          <DialogHeader>
            <DialogTitle className="text-2xl font-headline font-bold text-primary uppercase italic">Reset Password</DialogTitle>
            <DialogDescription className="text-xs text-muted-foreground uppercase tracking-widest pt-2">Account Recovery Registry</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleResetPassword} className="space-y-6 py-4">
            <div className="space-y-2">
              <Label className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">Registered Gmail Address</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input type="email" placeholder="example@gmail.com" className="pl-10 bg-white/5 border-white/10 h-12" required value={forgotEmail} onChange={(e) => setForgotEmail(e.target.value)} />
              </div>
            </div>
            <Button type="submit" disabled={isSendingReset} className="w-full bg-primary text-black font-black h-12 uppercase tracking-widest text-xs neon-gold">
              {isSendingReset ? <Loader2 className="animate-spin" /> : "Authorize Reset"}
            </Button>
            <div className="text-center">
               <button type="button" onClick={() => { setShowForgotDialog(false); setShowLoginDialog(true); }} className="text-[10px] font-bold text-muted-foreground hover:text-primary uppercase tracking-widest">Back to Login</button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </>
  )
}
