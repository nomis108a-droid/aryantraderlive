"use client"

import { useState } from "react"
import { useFirestore, useAuth } from "@/firebase"
import { collection, addDoc, setDoc, doc, serverTimestamp } from "firebase/firestore"
import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { CircleCheck, Upload, Loader2, Instagram, User, MessageCircle, Mail, Lock } from "lucide-react"
import { compressImage } from "@/lib/image-utils"
import { uploadToSupabase } from "@/lib/supabase"
import { useRouter } from "next/navigation"

export default function RegisterPage() {
  const db = useFirestore()
  const auth = useAuth()
  const router = useRouter()
  const { toast } = useToast()
  
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState<string | null>(null)
  
  const [formData, setFormData] = useState({ 
    creatorName: "", 
    handle: "", 
    email: "", 
    phoneNumber: "", 
    password: "", 
    confirmPassword: "" 
  })
  const [file, setFile] = useState<File | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!db || !auth || !file) {
      if (!file) toast({ variant: "destructive", title: "Proof Required", description: "Please upload a screenshot of your dashboard." });
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      toast({ variant: "destructive", title: "Password Mismatch", description: "Passwords do not match." });
      return;
    }

    if (formData.password.length < 6) {
      toast({ variant: "destructive", title: "Security Warning", description: "Password must be at least 6 characters." });
      return;
    }

    setLoading(true);
    try {
      // 1. Create Auth User
      const userCredential = await createUserWithEmailAndPassword(auth, formData.email, formData.password);
      const firebaseUser = userCredential.user;

      // 2. Update Auth Profile
      await updateProfile(firebaseUser, { displayName: formData.creatorName });

      // 3. Upload Proof Image
      const compressedBlob = await compressImage(file, 1000, 0.6);
      const screenshotUrl = await uploadToSupabase(compressedBlob, 'registrations/proofs');

      const handle = formData.handle.replace('@', '').toLowerCase().trim();

      // 4. Save to Firestore
      const regData = {
        creatorName: formData.creatorName,
        handle,
        followerCount: 0, // Follower count is now updated by admins after verification
        phoneNumber: formData.phoneNumber,
        screenshotUrl,
        userId: firebaseUser.uid,
        status: "pending",
        createdAt: serverTimestamp(),
      }

      const userData = {
        uid: firebaseUser.uid,
        displayName: formData.creatorName,
        handle,
        email: formData.email,
        whatsappNumber: formData.phoneNumber,
        isAdmin: false,
        createdAt: new Date().toISOString()
      }

      await setDoc(doc(db, "users", firebaseUser.uid), userData);
      await addDoc(collection(db, "registrations"), regData);

      setSuccess(handle)
      toast({ title: "Account Secured", description: "Welcome to the Aryan Gold Hub." })
    } catch (err: any) {
      console.error(err);
      toast({ variant: "destructive", title: "Registration Failed", description: err.message });
    } finally {
      setLoading(false)
    }
  }

  if (success) return (
    <div className="container mx-auto px-4 pt-20 flex justify-center text-center">
      <div className="glass-card p-12 max-w-lg border-primary">
        <CircleCheck className="w-20 h-20 text-primary mx-auto mb-6" />
        <h1 className="text-4xl font-bold mb-4">Account Verified!</h1>
        <p className="text-xl text-muted-foreground mb-8">Registered as <span className="text-primary font-bold">@{success}</span></p>
        <Button onClick={() => router.push("/dashboard")} className="w-full h-14 bg-primary text-black font-bold uppercase tracking-widest">Enter Hub Dashboard</Button>
      </div>
    </div>
  )

  return (
    <div className="container mx-auto px-4 py-24 max-w-4xl">
      <div className="text-center mb-12">
        <h1 className="text-5xl md:text-7xl font-headline font-bold mb-4">Join The Hub</h1>
        <p className="text-muted-foreground uppercase tracking-[0.3em] text-xs font-bold">Official Creator Registry</p>
      </div>

      <form onSubmit={handleSubmit} className="glass-card p-8 md:p-12 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-2">
            <Label className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">Full Name</Label>
            <div className="relative">
              <User className="absolute left-3 top-3.5 w-4 h-4 text-muted-foreground" />
              <Input className="pl-10 bg-white/5 border-white/10 h-12" required value={formData.creatorName} onChange={e => setFormData({...formData, creatorName: e.target.value})} />
            </div>
          </div>
          <div className="space-y-2">
            <Label className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">Instagram ID</Label>
            <div className="relative">
              <Instagram className="absolute left-3 top-3.5 w-4 h-4 text-muted-foreground" />
              <Input placeholder="@handle" className="pl-10 bg-white/5 border-white/10 h-12" required value={formData.handle} onChange={e => setFormData({...formData, handle: e.target.value})} />
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-2">
            <Label className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">Gmail Address</Label>
            <div className="relative">
              <Mail className="absolute left-3 top-3.5 w-4 h-4 text-muted-foreground" />
              <Input type="email" placeholder="example@gmail.com" className="pl-10 bg-white/5 border-white/10 h-12" required value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} />
            </div>
          </div>
          <div className="space-y-2">
            <Label className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">WhatsApp Number</Label>
            <div className="relative">
              <MessageCircle className="absolute left-3 top-3.5 w-4 h-4 text-muted-foreground" />
              <Input placeholder="91XXXXXXXXXX" className="pl-10 bg-white/5 border-white/10 h-12" required value={formData.phoneNumber} onChange={e => setFormData({...formData, phoneNumber: e.target.value})} />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-2">
            <Label className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">Security Password</Label>
            <div className="relative">
              <Lock className="absolute left-3 top-3.5 w-4 h-4 text-muted-foreground" />
              <Input type="password" placeholder="••••••••" className="pl-10 bg-white/5 border-white/10 h-12" required value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})} />
            </div>
          </div>
          <div className="space-y-2">
            <Label className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">Confirm Password</Label>
            <Input type="password" placeholder="••••••••" className="bg-white/5 border-white/10 h-12" required value={formData.confirmPassword} onChange={e => setFormData({...formData, confirmPassword: e.target.value})} />
          </div>
        </div>

        <div className="space-y-2">
          <Label className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">Dashboard Screenshot (Proof)</Label>
          <div className="border-2 border-dashed border-white/10 rounded-xl p-8 text-center bg-white/5 relative group hover:border-primary/40 transition-colors">
            <input type="file" className="absolute inset-0 opacity-0 cursor-pointer" accept="image/*" onChange={e => setFile(e.target.files?.[0] || null)} />
            <div className="flex flex-col items-center gap-2">
              <Upload className="w-8 h-8 text-muted-foreground group-hover:text-primary transition-colors" />
              {file ? <p className="text-primary font-bold text-sm">{file.name}</p> : <p className="text-[10px] uppercase font-bold text-muted-foreground">Upload growth verification proof</p>}
            </div>
          </div>
        </div>

        <Button type="submit" disabled={loading} className="w-full h-16 bg-primary text-black font-black uppercase tracking-[0.2em] text-sm shadow-[0_0_30px_rgba(255,215,0,0.3)] neon-gold">
          {loading ? <Loader2 className="animate-spin mr-2" /> : "Authorize & Register"}
        </Button>
      </form>
    </div>
  )
}
